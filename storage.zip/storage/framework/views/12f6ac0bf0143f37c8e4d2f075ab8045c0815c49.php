<?php echo e($slot); ?>

<?php /**PATH /Volumes/my-works/laravel/whatsserver/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/table.blade.php ENDPATH**/ ?>