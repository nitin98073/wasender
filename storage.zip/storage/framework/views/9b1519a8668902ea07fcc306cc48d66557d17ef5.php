 <div class="tp-choose__area pt-120 pb-90" data-background="assets/frontend/img/choose/choose-bg.png">
         <div class="container">
            <div class="row">
               <div class="col-12">
                  <div class="tp-choose__title-box text-center">
                     <h3 class="tp-section-title text-white mb-20 wow tpfadeUp" data-wow-duration=".7s" data-wow-delay=".3s">Why choose Quitox 🎖️</h3>
                     <h5 class="tp-choose__subtitle text-white wow tpfadeUp" data-wow-duration=".7s" data-wow-delay=".5s">Download apps</h5>
                  </div>
                  <div class="tp-choose__thumb-box d-flex justify-content-center wow tpfadeUp" data-wow-duration=".7s" data-wow-delay=".7s">
                     <div class="tp-choose__thumb-sm">
                        <a href="#"><img src="assets/frontend/img/app/app-2.png" alt=""></a>
                     </div>
                     <div class="tp-choose__thumb-sm">
                        <a href="#"><img src="assets/frontend/img/app/app-3.png" alt=""></a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div><?php /**PATH /Volumes/my-works/laravel/qserve/resources/views/frontend/sections/choose-area.blade.php ENDPATH**/ ?>